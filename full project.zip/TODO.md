# Deployment Plan for Free Hosting (Render + Vercel)

## Steps to Complete

- [x] Update README.md with detailed deployment guide (MongoDB Atlas setup, Render backend deployment, Vercel frontend deployment)
- [x] Update frontend/script.js to use production API base URL (replace localhost with Render backend URL)
- [ ] Test deployments locally (ensure backend runs with production env vars)
- [ ] Deploy backend to Render (link GitHub repo, set env vars: MONGODB_URI, JWT_SECRET, PORT)
- [ ] Deploy frontend to Vercel (upload static files, configure API calls)
- [ ] Verify CORS and API calls work in production
- [ ] Monitor free tier limits (Render: 750 hours/month, Vercel: 100GB bandwidth/month)
