// API Base URL - Change this to your backend URL
const API_BASE_URL = 'http://localhost:3000/api';

// Global variables
let cart = [];
let currentUser = null;
let menuItems = [];

// DOM Elements
const cartModal = document.querySelector('.cart-modal');
const cartIcon = document.querySelector('.cart-icon');
const closeCart = document.querySelector('.close-cart');
const cartItemsContainer = document.querySelector('.cart-items');
const cartCount = document.querySelector('.cart-count');
const totalPrice = document.querySelector('.total-price');
const menuItemsContainer = document.querySelector('.menu-items');
const menuSection = document.querySelector('.menu-section');
const categoryButtons = document.querySelectorAll('.category-btn');
const loginBtn = document.getElementById('loginBtn');
const customerPanel = document.getElementById('customerPanel');
const adminLoginModal = document.getElementById('adminLoginModal');
const adminLoginLink = document.getElementById('adminLoginLink');
const checkoutModal = document.getElementById('checkoutModal');
const checkoutBtn = document.querySelector('.checkout-btn');
const orderNowBtn = document.querySelector('.cta-button');

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    loadMenuItems();
    setupEventListeners();
    checkAuthenticationStatus();
});

// Setup event listeners
function setupEventListeners() {
    // Cart functionality
    cartIcon.addEventListener('click', () => {
        cartModal.classList.add('active');
    });

    closeCart.addEventListener('click', () => {
        cartModal.classList.remove('active');
    });

    // Category filtering
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            const category = button.getAttribute('data-category');
            displayMenuItems(category);
        });
    });

    // Authentication
    loginBtn.addEventListener('click', () => {
        customerPanel.style.display = 'block';
        window.scrollTo({
            top: customerPanel.offsetTop,
            behavior: 'smooth'
        });
    });

    // Admin login
    adminLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        adminLoginModal.classList.add('active');
    });

    // Close modals
    document.querySelectorAll('.close-modal').forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.classList.remove('active');
            });
        });
    });

    // Checkout
    checkoutBtn.addEventListener('click', () => {
        if (cart.length === 0) {
            alert('Your cart is empty!');
            return;
        }
        cartModal.classList.remove('active');
        checkoutModal.classList.add('active');
    });

    // Form submissions
    document.getElementById('loginFormElement').addEventListener('submit', handleLogin);
    document.getElementById('registerFormElement').addEventListener('submit', handleRegister);
    document.getElementById('adminLoginForm').addEventListener('submit', handleAdminLogin);
    document.getElementById('checkoutForm').addEventListener('submit', handleCheckout);

    // Toggle between login and register forms
    document.getElementById('showRegister').addEventListener('click', (e) => {
        e.preventDefault();
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('registerForm').style.display = 'block';
    });

    document.getElementById('showLogin').addEventListener('click', (e) => {
        e.preventDefault();
        document.getElementById('registerForm').style.display = 'none';
        document.getElementById('loginForm').style.display = 'block';
    });

    // Panel tabs
    document.querySelectorAll('.panel-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.panel-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const tabName = tab.getAttribute('data-tab');
            loadPanelContent(tabName);
        });
    });

    // Scroll indicator click to scroll to menu
    const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        scrollIndicator.addEventListener('click', () => {
            if (menuSection) {
                menuSection.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    }
}

// Load menu items from API
async function loadMenuItems() {
    try {
        const response = await fetch(`${API_BASE_URL}/menu`);
        menuItems = await response.json();
        displayMenuItems();
    } catch (error) {
        console.error('Error loading menu items:', error);
        // Fallback to sample data if API is not available
        menuItems = getSampleMenuItems();
        displayMenuItems();
    }
}

// Display menu items
function displayMenuItems(category = 'all') {
    menuItemsContainer.innerHTML = '';
    
    const filteredItems = category === 'all' 
        ? menuItems 
        : menuItems.filter(item => item.category === category);
    
    filteredItems.forEach(item => {
        const menuItemElement = document.createElement('div');
        menuItemElement.classList.add('menu-item');
        menuItemElement.innerHTML = `
            <div class="item-image" style="background-image: url('${item.image}')"></div>
            <div class="item-details">
                <h3 class="item-name">${item.name}</h3>
                <p class="item-description">${item.description}</p>
                <div class="item-price">$${item.price.toFixed(2)}</div>
                <button class="add-to-cart" data-id="${item.id}">Add to Cart</button>
            </div>
        `;
        menuItemsContainer.appendChild(menuItemElement);
    });
    
    // Add event listeners to add to cart buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', addToCart);
    });
}

// Add item to cart
function addToCart(e) {
    const itemId = parseInt(e.target.getAttribute('data-id'));
    const item = menuItems.find(menuItem => menuItem.id === itemId);
    
    const existingItem = cart.find(cartItem => cartItem.id === itemId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...item,
            quantity: 1
        });
    }
    
    updateCart();
    
    // Show cart modal
    cartModal.classList.add('active');
}

// Update cart display
function updateCart() {
    cartItemsContainer.innerHTML = '';
    
    let total = 0;
    let count = 0;
    
    cart.forEach(item => {
        const cartItemElement = document.createElement('div');
        cartItemElement.classList.add('cart-item');
        cartItemElement.innerHTML = `
            <div class="cart-item-image" style="background-image: url('${item.image}')"></div>
            <div class="cart-item-details">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                <div class="cart-item-quantity">
                    <button class="quantity-btn minus" data-id="${item.id}">-</button>
                    <span class="quantity">${item.quantity}</span>
                    <button class="quantity-btn plus" data-id="${item.id}">+</button>
                </div>
                <button class="remove-item" data-id="${item.id}">Remove</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItemElement);
        
        total += item.price * item.quantity;
        count += item.quantity;
    });
    
    totalPrice.textContent = `$${total.toFixed(2)}`;
    cartCount.textContent = count;
    
    // Add event listeners to quantity buttons
    document.querySelectorAll('.quantity-btn.minus').forEach(button => {
        button.addEventListener('click', decreaseQuantity);
    });
    
    document.querySelectorAll('.quantity-btn.plus').forEach(button => {
        button.addEventListener('click', increaseQuantity);
    });
    
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', removeItem);
    });
}

// Decrease item quantity
function decreaseQuantity(e) {
    const itemId = parseInt(e.target.getAttribute('data-id'));
    const item = cart.find(item => item.id === itemId);
    
    if (item.quantity > 1) {
        item.quantity -= 1;
    } else {
        cart = cart.filter(cartItem => cartItem.id !== itemId);
    }
    
    updateCart();
}

// Increase item quantity
function increaseQuantity(e) {
    const itemId = parseInt(e.target.getAttribute('data-id'));
    const item = cart.find(item => item.id === itemId);
    
    item.quantity += 1;
    updateCart();
}

// Remove item from cart
function removeItem(e) {
    const itemId = parseInt(e.target.getAttribute('data-id'));
    cart = cart.filter(item => item.id !== itemId);
    updateCart();
}

// Handle user login
async function handleLogin(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const credentials = {
        email: formData.get('email'),
        password: formData.get('password')
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        });
        
        if (response.ok) {
            const user = await response.json();
            currentUser = user;
            localStorage.setItem('user', JSON.stringify(user));
            showMessage('Login successful!', 'success');
            updateAuthUI();
            loadPanelContent('profile');
        } else {
            showMessage('Invalid email or password', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showMessage('Login failed. Please try again.', 'error');
    }
}

// Handle user registration
async function handleRegister(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const userData = {
        name: formData.get('name'),
        email: formData.get('email'),
        password: formData.get('password'),
        phone: formData.get('phone')
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        
        if (response.ok) {
            showMessage('Registration successful! Please login.', 'success');
            document.getElementById('registerForm').style.display = 'none';
            document.getElementById('loginForm').style.display = 'block';
        } else {
            showMessage('Registration failed. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Registration error:', error);
        showMessage('Registration failed. Please try again.', 'error');
    }
}

// Handle admin login
async function handleAdminLogin(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const credentials = {
        adminId: formData.get('adminId'),
        password: formData.get('password')
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/admin-login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        });
        
        if (response.ok) {
            const admin = await response.json();
            localStorage.setItem('admin', JSON.stringify(admin));
            showMessage('Admin login successful!', 'success');
            adminLoginModal.classList.remove('active');
            // Redirect to admin panel (in a real app, this would navigate to a separate admin page)
            window.location.href = '/admin.html';
        } else {
            showMessage('Invalid admin credentials', 'error');
        }
    } catch (error) {
        console.error('Admin login error:', error);
        showMessage('Admin login failed. Please try again.', 'error');
    }
}

// Handle checkout
async function handleCheckout(e) {
    e.preventDefault();
    
    if (!currentUser) {
        showMessage('Please login to complete your order', 'error');
        customerPanel.style.display = 'block';
        checkoutModal.classList.remove('active');
        return;
    }
    
    const orderData = {
        userId: currentUser.id,
        items: cart,
        total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        deliveryAddress: document.getElementById('checkoutAddress').value,
        phone: document.getElementById('checkoutPhone').value,
        paymentMethod: document.getElementById('checkoutPayment').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/orders`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentUser.token}`
            },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            const order = await response.json();
            showMessage('Order placed successfully!', 'success');
            cart = [];
            updateCart();
            checkoutModal.classList.remove('active');
            // In a real app, you might redirect to an order confirmation page
        } else {
            showMessage('Failed to place order. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Checkout error:', error);
        showMessage('Failed to place order. Please try again.', 'error');
    }
}

// Load panel content
function loadPanelContent(tabName) {
    const panelContent = document.querySelector('.panel-content');
    
    if (!currentUser) {
        document.getElementById('loginForm').style.display = 'block';
        document.getElementById('registerForm').style.display = 'none';
        document.getElementById('profileContent').style.display = 'none';
        return;
    }
    
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('profileContent').style.display = 'block';
    
    let content = '';
    
    switch(tabName) {
        case 'profile':
            content = `
                <h3>My Profile</h3>
                <div class="profile-info">
                    <p><strong>Name:</strong> ${currentUser.name}</p>
                    <p><strong>Email:</strong> ${currentUser.email}</p>
                    <p><strong>Phone:</strong> ${currentUser.phone}</p>
                    <button class="edit-profile-btn">Edit Profile</button>
                    <button class="logout-btn" style="margin-left: 10px;">Logout</button>
                </div>
            `;
            break;
        case 'orders':
            content = `
                <h3>Order History</h3>
                <div class="order-list" id="orderList">
                    <p>Loading orders...</p>
                </div>
            `;
            loadUserOrders();
            break;
        case 'addresses':
            content = `
                <h3>My Addresses</h3>
                <div class="address-list">
                    <div class="address-item">
                        <p><strong>Default Address</strong></p>
                        <p>${currentUser.address || 'No address saved'}</p>
                        <button class="edit-address-btn">Edit</button>
                    </div>
                </div>
                <button class="add-address-btn">Add New Address</button>
            `;
            break;
    }
    
    document.getElementById('profileContent').innerHTML = content;
    
    // Add event listeners for buttons in the panel
    if (document.querySelector('.logout-btn')) {
        document.querySelector('.logout-btn').addEventListener('click', handleLogout);
    }
}

// Load user orders
async function loadUserOrders() {
    try {
        const response = await fetch(`${API_BASE_URL}/orders/user/${currentUser.id}`, {
            headers: {
                'Authorization': `Bearer ${currentUser.token}`
            }
        });
        
        if (response.ok) {
            const orders = await response.json();
            const orderList = document.getElementById('orderList');
            
            if (orders.length === 0) {
                orderList.innerHTML = '<p>No orders found.</p>';
                return;
            }
            
            orderList.innerHTML = orders.map(order => `
                <div class="order-item">
                    <p><strong>Order #${order.id}</strong> - $${order.total.toFixed(2)} - ${new Date(order.createdAt).toLocaleDateString()}</p>
                    <p>Status: <span class="order-status">${order.status}</span></p>
                </div>
            `).join('');
        } else {
            document.getElementById('orderList').innerHTML = '<p>Failed to load orders.</p>';
        }
    } catch (error) {
        console.error('Error loading orders:', error);
        document.getElementById('orderList').innerHTML = '<p>Failed to load orders.</p>';
    }
}

// Handle logout
function handleLogout() {
    currentUser = null;
    localStorage.removeItem('user');
    updateAuthUI();
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('profileContent').style.display = 'none';
}

// Check authentication status
function checkAuthenticationStatus() {
    const user = localStorage.getItem('user');
    if (user) {
        currentUser = JSON.parse(user);
        updateAuthUI();
    }
}

// Update authentication UI
function updateAuthUI() {
    if (currentUser) {
        loginBtn.textContent = 'My Account';
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('profileContent').style.display = 'block';
    } else {
        loginBtn.textContent = 'Login';
    }
}

// Show message
function showMessage(message, type) {
    // Create message element
    const messageEl = document.createElement('div');
    messageEl.className = `message ${type}`;
    messageEl.textContent = message;
    messageEl.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 5px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    
    if (type === 'success') {
        messageEl.style.backgroundColor = 'var(--success)';
    } else {
        messageEl.style.backgroundColor = 'var(--error)';
    }
    
    document.body.appendChild(messageEl);
    
    // Remove message after 3 seconds
    setTimeout(() => {
        messageEl.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(messageEl);
        }, 300);
    }, 3000);
}

// Sample menu items (fallback if API is not available)
function getSampleMenuItems() {
    return [
        {
            id: 1,
            name: "Chocolate Fudge Cake",
            category: "cakes",
            price: 24.99,
            description: "Rich and moist chocolate cake with fudge frosting",
            image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1089&q=80"
        },
        {
            id: 2,
            name: "Red Velvet Cake",
            category: "cakes",
            price: 26.99,
            description: "Classic red velvet with cream cheese frosting",
            image: "https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80"
        },
        {
            id: 3,
            name: "Fruit Tart",
            category: "pastries",
            price: 5.99,
            description: "Buttery crust filled with custard and fresh fruits",
            image: "https://images.unsplash.com/photo-1565958011703-44f9829ba187?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=765&q=80"
        },
        {
            id: 4,
            name: "Croissant",
            category: "pastries",
            price: 3.49,
            description: "Flaky, buttery French croissant",
            image: "https://images.unsplash.com/photo-1555507036-ab794f27d2e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
        },
        {
            id: 5,
            name: "Sourdough Bread",
            category: "breads",
            price: 6.99,
            description: "Artisan sourdough with crispy crust",
            image: "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
        },
        {
            id: 6,
            name: "Whole Wheat Bread",
            category: "breads",
            price: 5.49,
            description: "Healthy whole wheat bread",
            image: "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
        },
        {
            id: 7,
            name: "Chocolate Chip Cookies",
            category: "cookies",
            price: 2.99,
            description: "Classic cookies with chocolate chips",
            image: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=764&q=80"
        },
        {
            id: 8,
            name: "Macarons",
            category: "cookies",
            price: 12.99,
            description: "Assorted French macarons",
            image: "https://images.unsplash.com/photo-1558326567-98ae2405596b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=780&q=80"
        }
    ];
}